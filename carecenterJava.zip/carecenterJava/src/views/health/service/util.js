const module = '/servicetargets'
export default {
	list: module + '/list',
	del: module + '/del',
	check: module + '/check',
	update: module + '/update',
	getById: module + '/getById',
	set: module + '/set'
}