package com.neuedu.mapper;

import com.neuedu.entity.Busroute;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zhaojie
 * @since 2024-09-02
 */
public interface BusrouteMapper extends BaseMapper<Busroute> {

}
