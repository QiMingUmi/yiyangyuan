package com.neuedu.service;

import com.neuedu.entity.Busroute;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhaojie
 * @since 2024-09-02
 */
public interface BusrouteService extends IService<Busroute> {

}
