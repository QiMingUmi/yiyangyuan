package com.neuedu.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhaojie
 * @since 2024-09-02
 */
@RestController
@RequestMapping("/busroute")
public class BusrouteController {

}
