package com.neuedu.test;

import com.aventrix.jnanoid.jnanoid.NanoIdUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.UUID;

public class Main {
    public static void main(String[] args) {
    }
}
