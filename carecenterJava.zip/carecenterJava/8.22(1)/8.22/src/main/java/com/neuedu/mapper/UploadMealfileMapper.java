package com.neuedu.mapper;

import com.neuedu.entity.UploadMealfile;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 文件表 Mapper 接口
 * </p>
 *
 * @author limengya
 * @since 2024-08-08
 */
public interface UploadMealfileMapper extends BaseMapper<UploadMealfile> {

}
