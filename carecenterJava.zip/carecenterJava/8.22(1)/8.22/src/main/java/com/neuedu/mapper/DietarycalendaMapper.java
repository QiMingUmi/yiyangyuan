package com.neuedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.Dietarycalendar;

public interface DietarycalendaMapper extends BaseMapper<Dietarycalendar>{

}
