package com.neuedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.Lccontrast;
import com.neuedu.entity.Tem;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mengxiang
 * @since 2024-08-15
 */

public interface LccontrastMapper extends BaseMapper<Lccontrast> {

    List<Tem> getbyID(Integer id) ;


     List selectFullJoinData(Integer lid);
}
