package com.neuedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.Busroute;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zhaojie
 * @since 2024-09-02
 */
public interface BusrouteMapper extends BaseMapper<Busroute> {

}
