package com.neuedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.Bedroom;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ylx
 * @since 2024-08-17
 */
public interface BedroomMapper extends BaseMapper<Bedroom> {

}
