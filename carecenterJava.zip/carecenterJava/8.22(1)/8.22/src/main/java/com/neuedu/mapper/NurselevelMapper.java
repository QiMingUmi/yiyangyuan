package com.neuedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neuedu.entity.Nurselevel;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mengxiang
 * @since 2024-08-12
 */
public interface NurselevelMapper extends BaseMapper<Nurselevel> {

}
