package com.neuedu.core;

public class NeueduException extends RuntimeException {

    public NeueduException(String message) {
        super(message);
    }
}
